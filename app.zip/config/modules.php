<?php

return [  
    'payment'=>[
        'status'=>1,
        'route'=>'modules/subscription/routes/web.php',

    ],
    'subscription'=>[       
        'status'=>1,
        'route'=>'modules/subscription/routes/web.php',
    ], 
];