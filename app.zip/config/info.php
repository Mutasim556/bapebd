<?php


return [
    'institute_name'=>'Bipe BD',
    'institute_website'=>'bipebd.com',
];
